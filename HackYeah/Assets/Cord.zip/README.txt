Co to Cord?
Cord to narzędzie do Unity służące do intuicyjnego tworzenia dialogów przy pomocy węzłów i grafów, a następnie importowania ich jako .json lub .asset dla systemów dialogowych, a także do importu dialogów z Twine'a.

Jak użyć Corda?
Aby móc korzystać z Corda, należy rozpakować plik Cord.zip w projekcie Unity (wersja Unity 6.0+), do folderu Assets. Następnie w pasku narzędni unity wybrać "Window -> Dialogue Graph". Przykładowe pliki do importowania znajdują się w pliku Cord.zip w folderze SampleFiles.