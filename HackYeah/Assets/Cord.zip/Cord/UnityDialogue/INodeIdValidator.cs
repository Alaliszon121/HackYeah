public interface INodeIdValidator
{
    bool IsIdUsed(string id);
}
